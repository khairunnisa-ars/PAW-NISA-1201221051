

<?php $__env->startSection('title', 'Profil Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Data Profil Mahasiswa</h3>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                <th>Nama</th>
                <td><?php echo e($mahasiswa->nama); ?></td>
            </tr>
            <tr>
                <th>NIM</th>
                <td><?php echo e($mahasiswa->nim); ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo e($mahasiswa->email); ?></td>
            </tr>
            <tr>
                <th>Jurusan</th>
                <td><?php echo e($mahasiswa->jurusan); ?></td>
            </tr>
            <tr>
                <th>Fakultas</th>
                <td><?php echo e($mahasiswa->fakultas); ?></td>
            </tr>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\zlire\OneDrive\Documents\Kulyeah\Asprak WAD\Kunjaw\Modul 3\Jurnal\resources\views/profil.blade.php ENDPATH**/ ?>