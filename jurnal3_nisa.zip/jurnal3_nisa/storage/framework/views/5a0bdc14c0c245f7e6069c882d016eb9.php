

<?php $__env->startSection('title', 'Profil Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Data Profil Mahasiswa</h3>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                <th>Name</th>
                <td><?php echo e($student->name); ?></td>
            </tr>
            <tr>
                <th>NIM</th>
                <td><?php echo e($student->nim); ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo e($student->email); ?></td>
            </tr>
            <tr>
                <th>Major</th>
                <td><?php echo e($student->major); ?></td>
            </tr>
            <tr>
                <th>Faculty</th>
                <td><?php echo e($student->faculty); ?></td>
            </tr>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\zlire\OneDrive\Documents\Kulyeah\Asprak WAD\Kunjaw\Modul 3\Jurnal_KJ\resources\views/profile.blade.php ENDPATH**/ ?>