

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <?php if(session('error') || session('success')): ?>
        <?php
            $type = session('error') ? 'error' : 'success';
            $message = session($type);
            $bgColor = $type === 'error' ? 'bg-red-500' : 'bg-green-500';
            $id = $type . 'Message';
            $closeFunction = 'close' . ucfirst($type) . 'Message';
        ?>

        <div id="<?php echo e($id); ?>" class="<?php echo e($bgColor); ?> text-white p-4 rounded-lg mb-6 relative">
            <span><?php echo e($message); ?></span>
            <button class="absolute right-5 text-white font-bold" onclick="<?php echo e($closeFunction); ?>()">X</button>
        </div>

        <script>
            function <?php echo e($closeFunction); ?>() {
                document.getElementById('<?php echo e($id); ?>').classList.add('hidden');
            }

            setTimeout(function() {
                var el = document.getElementById('<?php echo e($id); ?>');
                if (el) el.classList.add('hidden');
            }, 5000);
        </script>
    <?php endif; ?>

    <div class="bg-white p-8 rounded shadow-lg">
        <?php if($article->image): ?>
            <img src="<?php echo e(asset('storage/' . $article->image)); ?>" alt="<?php echo e($article->title); ?>" class="w-full h-104 object-cover rounded mb-4">
        <?php endif; ?>

        <div class="flex justify-between items-center mb-4">
            <h1 class="text-3xl font-bold text-gray-800"><?php echo e($article->title); ?></h1>
            <p class="text-sm text-gray-500 text-justify"><?php echo e($article->created_at->timezone('Asia/Jakarta')->format('d M Y, H:i')); ?></p>
        </div>
        <p class="mt-4 text-gray-700"><?php echo e($article->content); ?></p>
    </div>

    <?php if(auth()->check() && (auth()->user()->role == 'mahasiswa' || auth()->user()->role == 'admin')): ?>
        <div class="mt-8">
            <h2 class="text-xl font-semibold mb-2">Tinggalkan Komentar</h2>
            <form method="POST" action="/articles/<?php echo e($article->id); ?>/comments">
                <?php echo csrf_field(); ?>
                <textarea name="comment" rows="3" class="w-full border border-gray-300 p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-500" required></textarea>
                <button class="mt-4 bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition duration-300">
                    Kirim
                </button>
            </form>
        </div>
    <?php endif; ?>

    <div class="mt-8">
        <h2 class="text-xl font-semibold mb-4">Komentar</h2>
        <?php $__empty_1 = true; $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-gray-100 p-4 mb-3 rounded-lg shadow-sm">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-1">
                        <span class="material-icons text-gray-600 text-2xl">
                            account_circle
                        </span>
                        <p class="text-sm font-semibold text-gray-800"><?php echo e($comment->user->name); ?></p>
                    </div>
                    <?php if(auth()->check() && auth()->id() == $comment->user_id): ?>
                        <form action="<?php echo e(route('comment.destroy', $comment)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:underline">Hapus</button>
                        </form>
                    <?php endif; ?>
                </div>
                <p class="text-xs text-gray-500">
                    <?php echo e(\Carbon\Carbon::parse($comment->created_at)->timezone('Asia/Jakarta')->format('d M Y, H:i')); ?>

                </p>
                <p class="text-gray-700 text-justify mt-2"><?php echo e($comment->comment); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-500">Belum ada komentar.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/PAW-NISA-1201221051/JURNAL_MODUL_4_REG/resources/views/articles/show.blade.php ENDPATH**/ ?>