<!DOCTYPE html>
<html>
<head>
    <title>SeputarTelkom</title>
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('/logo.png')); ?>" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <nav class="bg-white shadow-md p-4 flex justify-between items-center">
        <a href="<?php echo e(route('home')); ?>" class="flex items-center space-x-2">
            <img src="/logo.png" alt="Logo" class="w-8 h-8">
            <span class="text-lg font-bold text-gray-800">SeputarTelkom</span>
        </a>
        <div>
            <?php if(auth()->guard()->check()): ?>
                <div class="flex items-center space-x-6">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-gray-600 text-4xl">
                            account_circle
                        </span>
                        <div class="text-left leading-tight">
                            <p class="text-sm font-semibold text-gray-800">
                                <?php echo e(Auth::user()->name); ?>

                            </p>
                            <p class="text-xs text-gray-500">
                                <?php echo e(Auth::user()->email); ?>

                            </p>
                        </div>
                    </div>

                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                    <?php echo csrf_field(); ?>
                        <button type="submit"
                                class="bg-red-500 text-white px-6 py-2 rounded-full hover:bg-red-600 transition duration-300">
                            Logout
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <?php if(Request::is('login')): ?>
                    <a href="/register" class="bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600 transition duration-300">Register</a>
                <?php else: ?>
                    <a href="/login" class="bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600 transition duration-300">Login</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </nav>
    <div class="container mx-auto p-4">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH C:\Users\Acer NITRO 5\Documents\Mengoding\Modul4\PAW_MODUL4_REG\resources\views/layouts/app.blade.php ENDPATH**/ ?>