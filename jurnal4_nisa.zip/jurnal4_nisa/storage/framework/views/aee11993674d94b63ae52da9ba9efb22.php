<?php $__env->startSection('content'); ?>
<?php if(session('error') || session('success')): ?>
    <?php
        $type = session('error') ? 'error' : 'success';
        $message = session($type);
        $bgColor = $type === 'error' ? 'bg-red-500' : 'bg-green-500';
        $id = $type . 'Message';
        $closeFunction = 'close' . ucfirst($type) . 'Message';
    ?>

    <div id="<?php echo e($id); ?>" class="<?php echo e($bgColor); ?> text-white p-4 rounded-lg mb-6 relative">
        <span><?php echo e($message); ?></span>
        <button class="absolute right-5 text-white font-bold" onclick="<?php echo e($closeFunction); ?>()">X</button>
    </div>

    <script>
        function <?php echo e($closeFunction); ?>() {
            document.getElementById('<?php echo e($id); ?>').classList.add('hidden');
        }

        setTimeout(function() {
            var el = document.getElementById('<?php echo e($id); ?>');
            if (el) el.classList.add('hidden');
        }, 5000);
    </script>
<?php endif; ?>

<div class="bg-white p-6 rounded shadow mb-4">
    <?php if(auth()->guard()->check()): ?>
        <h1 class="text-2xl font-semibold mb-2">Selamat datang, <?php echo e(Auth::user()->name); ?>!</h1>

        <?php if(session('status')): ?>
            <div class="bg-green-100 text-green-800 p-2 rounded mb-4">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        
        <p class="text-gray-700 mb-4">Dapatkan update terkini dan berita seputar Telkom University di sini!</p>

        <!-- Tampilkan tombol untuk ke halaman admin.index -->

        <?php if(Auth::user()->role === 'admin'): ?>
            <a href="<?php echo e(route('admin.index')); ?>" class="inline-block bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition duration-300">
                Admin
            </a>
        <?php endif; ?>
    <?php else: ?>
        <h1 class="text-2xl font-semibold mb-2">Selamat datang!</h1>
        <p class="text-gray-700">Silakan login untuk mendapatkan pengalaman terbaik.</p>
    <?php endif; ?>
</div>

<div class="bg-white p-6 rounded shadow">
    <h2 class="text-xl font-bold mb-4">Artikel Terbaru</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="block bg-white p-4 rounded-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition duration-200">
                <?php if($article->image): ?>
                    <img src="<?php echo e(asset('storage/' . $article->image)); ?>" alt="<?php echo e($article->title); ?>" class="w-full h-28 object-cover rounded mb-4">
                <?php endif; ?>
                <h2 class="text-lg text-justify font-semibold text-gray-900"><?php echo e($article->title); ?></h2>
                <p class="text-sm text-gray-700 mt-2 text-justify mb-2"><?php echo e(Str::limit($article->content, 100)); ?></p>
                <a href="<?php echo e(route('articles.show', $article->id)); ?>" class="hover:underline text-blue-600 font-medium">Baca Selengkapnya</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-4 text-center text-gray-600 font-medium">
                Tidak Ada Artikel yang Tersedia.
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/PAW-NISA-1201221051/jurnal4_nisa/resources/views/home.blade.php ENDPATH**/ ?>